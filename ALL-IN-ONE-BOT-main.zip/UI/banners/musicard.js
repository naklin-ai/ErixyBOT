const path = require('path');

const data = {
    backgroundImages: [
        path.resolve(__dirname, '../musicimages/1.png'),
        path.resolve(__dirname, '../musicimages/2.jpg'),
        path.resolve(__dirname, '../musicimages/3.jpg'),
        path.resolve(__dirname, '../musicimages/4.jpg'),
        path.resolve(__dirname, '../musicimages/5.jpg'),
    ],
};

module.exports = data;
